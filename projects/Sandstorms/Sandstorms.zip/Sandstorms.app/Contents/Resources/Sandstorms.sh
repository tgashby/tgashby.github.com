if [[ -e "/Library/Frameworks/SDL2.framework" && -e "/Library/Frameworks/SDL2_mixer.framework" && -e "/Library/Frameworks/SDL2_image.framework" ]]; then
	#statements
	echo "Libraries already in correct place"
else
	cp -r SDL2.framework /Library/Frameworks/
	cp -r SDL2_mixer.framework /Library/Frameworks/
	cp -r SDL2_image.framework /Library/Frameworks/
fi

./Sandstorms